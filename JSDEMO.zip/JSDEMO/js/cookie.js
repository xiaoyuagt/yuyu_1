//1.设置cookie
function setCookie(key,value,iDay)
	 {
	    var oDate=new Date();
		oDate.setDate(oDate.getDate()+iDay);
		document.cookie=key+'='+encodeURI(value)+';expires='+oDate.toGMTString();
	 
	 }
//2.读取cookie
function getCookie(key) 
	 {
	 	
	  var arr=document.cookie.split('; ');  //字符串分隔
	  for(var i=0;i<arr.length;i++)
	  {
	        var arr2=arr[i].split('=');  
			if(arr2[0]==key)
			{
			   return decodeURI(arr2[1]);
			}
	  }
	  //如果用户从来就没登录过，没有记录下信息，这时返回空
	   return '';   
	 }
//3.删除cookie
function removeCookie(key)
	  {
	  	 //通过赋值-1，表示昨天已经过期了，赶紧删除
	    setCookie(key,1,-1);   
	  
	  }

