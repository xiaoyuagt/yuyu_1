/*1.�˶����*/ 

function getStyle(obj,name)  //��ȡ���м���ʽ
{
   if(obj.currentStyle)
   {
      return  obj.currentStyle[name];
   }
   else
   {
     return  getComputedStyle(obj,false)[name];
   
   }
}
//�˶����
function startMove(obj,attr,iTarget){                    //͸���ȱ仯Ҳ��һ���˶�
  clearInterval(obj.timer);
  obj.timer=setInterval(function(){
      var cur=0;
      if(attr=='opacity')
	  {
	      cur=parseFloat(getStyle(obj,attr))*100;
	  }
	  else
	  {
	   cur=parseInt(getStyle(obj,attr));
	  
	  }
  
    var speed=(iTarget-cur)/6;                      //��Ŀ��ԽԶ���ٶ�Խ��
	speed=speed>0 ? Math.ceil(speed): Math.floor(speed);  //����ȡ��������ȡ��
	if(cur==iTarget)
	{
	    clearInterval(obj.timer); 
	}
	else
	{
	   if(attr=='opacity')
	   {
	     obj.style.filter='alpha(opacity:'+(cur+speed)+')';    //IE�����
		 obj.style.opacity=(cur+speed)/100;                    //Firefox/Chrome�����
	   }
	   else
	   {
	    obj.style[attr]=cur+speed+'px';
	   }
	}
  },30);
};  

/*2.js����domԪ��class*/ 
 function hasClass(obj, cls) {  
	    return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
	}  
	  
	function addClass(obj, cls) {  
	    if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
	}  
	  
	function removeClass(obj, cls) {  
	    if (hasClass(obj, cls)) {  
	        var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
	        obj.className = obj.className.replace(reg, ' ');  
	    }  
	}  
	  
	function toggleClass(obj,cls){  
	    if(hasClass(obj,cls)){  
	        removeClass(obj, cls);  
	    }else{  
	        addClass(obj, cls);  
	    }  
	}  
	  
	function toggleClassTest(){  
	    var obj = document. getElementById('test');  
	    toggleClass(obj,"testClass");  
	}
